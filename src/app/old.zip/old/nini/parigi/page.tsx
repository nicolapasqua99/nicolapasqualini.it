import './page.css'

export default function Home() {
    return (
        <main>
            <div className="title">
                <h1>PROVA</h1>
            </div>
        </main>
    )
}
