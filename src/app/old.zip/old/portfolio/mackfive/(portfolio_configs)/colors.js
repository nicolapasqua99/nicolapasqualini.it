const primary = '#28827d'
const secondary = '#EFEEE5'
const tertiary = '#274546'

export {primary, secondary, tertiary}
